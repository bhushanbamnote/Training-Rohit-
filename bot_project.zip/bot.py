
print("Bot is running...")
# इथे तुझा Telegram bot किंवा Trading logic कोड टाका
