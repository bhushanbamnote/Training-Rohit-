
# Trading Chart Analysis Bot

## How to Deploy on Render

1. Create a new Web Service on Render.
2. Connect your GitHub Repository or Upload manually.
3. Set the **Start Command** as:
    ```
    python bot.py
    ```
4. Set the environment to **Python 3**.
5. Done! Your bot will start running.

---
Made with ❤️
